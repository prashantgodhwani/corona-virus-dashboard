var gdpData = {
    "UKF": '<br/> Cases - 854, <br/> Death - 125,<br/> Recoverd - 95',
    "WLS": '<br/> Cases - 2564, <br/> Death - 654,<br/> Recoverd - 326',
    "NIR": '<br/> Cases - 3654, <br/> Death - 754,<br/> Recoverd - 541',
    "UKK": '<br/> Cases - 5412, <br/> Death - 954,<br/> Recoverd - 365',
    "UKJ": '<br/> Cases - 6598, <br/> Death - 1024,<br/> Recoverd - 654',
    "UKI": '<br/> Cases - 854, <br/> Death - 95,<br/> Recoverd - 125',
    "UKH": '<br/> Cases - 1256, <br/> Death - 74,<br/> Recoverd - 256',
    "UKG": '<br/> Cases - 2541, <br/> Death - 965,<br/> Recoverd - 1024',
    "SCT": '<br/> Cases - 3654, <br/> Death - 458,<br/> Recoverd - 984',
    "UKE": '<br/> Cases - 2564, <br/> Death - 96,<br/> Recoverd - 564',
    "UKD": '<br/> Cases - 1564, <br/> Death - 75,<br/> Recoverd - 365',
    "UKC": '<br/> Cases - 1589, <br/> Death - 52,<br/> Recoverd - 521',
};