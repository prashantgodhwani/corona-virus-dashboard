var gdpData = {
    "AU-ACT": '<br/> Cases - 985, <br/> Death - 52,<br/> Recoverd - 254',
    "AU-WA": '<br/> Cases - 758, <br/> Death - 37,<br/> Recoverd - 108',
    "AU-TAS": '<br/> Cases - 1056, <br/> Death - 106,<br/> Recoverd - 254',
    "AU-": '<br/> Cases - 1254, <br/> Death - 108,<br/> Recoverd - 80',
    "AU-VIC": '<br/> Cases - 3698, <br/> Death - 96,<br/> Recoverd - 198',
    "AU-NT": '<br/> Cases - 854, <br/> Death - 78,<br/> Recoverd - 58',
    "AU-QLD": '<br/> Cases - 954, <br/> Death - 236,<br/> Recoverd - 70',
    "AU-SA": '<br/> Cases - 562, <br/> Death - 189,<br/> Recoverd - 68',
    "AU-NSW": '<br/> Cases - 362, <br/> Death - 87,<br/> Recoverd - 65',

};