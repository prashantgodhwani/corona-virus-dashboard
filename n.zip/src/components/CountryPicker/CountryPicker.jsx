import React, {Component} from 'react';
import {fetchZoneStats, fetchDistrictStats, fetchDistricts} from './../../api';

class CountryPicker extends Component{

  state = {
  query: '',
  results: []
}

debounceAPI  =  (func, delay) =>  {
  var timerId;
	// Cancels the setTimeout method execution
	clearTimeout(timerId)
  console.log("calling");
	// Executes the func after delay time.
	timerId  =  setTimeout(func, 3000)
  console.log("called");
}

setResponseToState = async () => {
    this.setState({results : await fetchDistricts(this.search.value)});
    console.log(this.state.results);
}

 handleInputChange = () => {

     // this.setState({
     //   results: await this.debounceAPI(fetchDistricts(this.search.value))
     // });

 this.debounceAPI(this.setResponseToState(), 3000);
}

render(){
return (
<div class="card box-margin">
  <div class="card-body">
    <div class="country-map">
      <div class="box-header">
        <h5 class="card-title">Country Wise Stats</h5>
      </div>
      <div class="dropdown show">
        <input
           placeholder="Search for..."
           ref={input => this.search = input}
           onChange={this.handleInputChange}
         />

        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </div>
    </div>
  </div>
</div>
);
}
}

export default CountryPicker;
